enum color{'RED','Green','Blue'};

console.log(color.RED)
