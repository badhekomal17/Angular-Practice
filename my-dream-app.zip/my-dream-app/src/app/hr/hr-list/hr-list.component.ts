import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hr-list',
  templateUrl: './hr-list.component.html',
  styleUrls: ['./hr-list.component.css']
})
export class HrListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
