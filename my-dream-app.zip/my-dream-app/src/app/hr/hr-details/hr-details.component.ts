import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hr-details',
  templateUrl: './hr-details.component.html',
  styleUrls: ['./hr-details.component.css']
})
export class HrDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
