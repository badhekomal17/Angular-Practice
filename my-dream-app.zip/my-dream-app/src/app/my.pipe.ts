import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'my'
})
export class MyPipe implements PipeTransform {

  transform(value: string,gender: string): string {

    console.log(value);

    console.log(gender);

    if(gender=="male")
      return "Mr."+value
    else
      return "Ms."+value;
  }

}
