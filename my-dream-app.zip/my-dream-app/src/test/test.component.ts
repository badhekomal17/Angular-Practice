import { Component } from '@angular/core';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',

   styleUrls: ['./test.component.css']

})

export class TestComponent {
  /*title = 'my-dream-app';*/

  
  employee:any[]=[
    {id:101,name:"Jyoti",salary:30000,gender:"female"},
    {id:102,name:"Ram",salary:30000,gender:"male"},
    {id:101,name:"Mayuri",salary:30000,gender:"female"},

  ]
}
