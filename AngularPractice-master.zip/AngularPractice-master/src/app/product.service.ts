import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  // Using Service
  getAllProducts() {
    return [{
      productId: 1,
      productName: "Leaf Rake",
      productCode: "GDN-0011",
      releaseDate: "March 19, 2016",
      description: "Leaf rake with 48-inch wooden handle.",
      price: 19.95,
      starRating: 3.2,
      imageUrl: "https://www.beatsons.co.uk/images/faithfull-leaf-rake-fibreglass-shaft-p7564-30639_medium.jpg"
},
     {
      productId: 2,
      productName: "Garden Cart",
      productCode: "GDN-0023",
      releaseDate: "March 18, 2016",
      description: "15 gallon capacity rolling garden cart",
      price: 32.99,
      starRating: 4.2,
      imageUrl: "https://images.homedepot-static.com/productImages/b2a0e937-99b7-40bb-a567-8b11a2eb63ef/svn/sontax-yard-carts-73599-64_1000.jpg"
  },
  {
      productId: 5,
      productName: "Hammer",
      productCode: "TBX-0048",
      releaseDate: "May 21, 2016",
      description: "Curved claw steel hammer",
      price: 8.9,
      starRating: 4.8,
      imageUrl: "https://www.jafcotools.com/wp-content/uploads/2015/11/AC24BS-Y_24oz_Claw-Hammer-1100x562.jpg"
  },
  {
      productId: 8,
      productName: "Saw",
      productCode: "TBX-0022",
      releaseDate: "May 15, 2016",
      description: "15-inch steel blade hand saw",
      price: 11.55,
      starRating: 3.7,
      imageUrl: "https://ae01.alicdn.com/kf/HTB1ZR10NXXXXXcyaXXXq6xXFXXXK/Popular-Carpenter-Tools-Home-Manual-Saw-Carbon-Steel-Blade-Tree-Branch-Cutter-Hand-Gardening-Hacksaw.jpg_640x640.jpg"
  },
  {
    productId: 10,
    productName: "Video Game",
    productCode: "GMG-0042",
    releaseDate: "October 15, 2015",
    description: "Standard two-button video game controller",
    price: 35.95,
    starRating: 4.6,
    imageUrl: "https://hips.hearstapps.com/pop.h-cdn.co/assets/cm/15/06/480x240/54cfd423c3fde_-_laptop-joysticks-01-1012-lgn.jpg?resize=980:*"
  }
]
  }

  /*constructor(private http:HttpClient) { }

  getAllProducts(){
    return this.http.get('/assets/data/product.json');
  }*/
}
